package com.kh.anroidexam;

import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class StudentDao {

    MyHelper helper;

    public StudentDao(MyHelper helper) {
        this.helper = helper;
    }

    private void closeAll(SQLiteDatabase database, SQLiteStatement statement, Cursor cursor) {
        if (database != null) database.close();
        if (statement != null) statement.close();
        if (cursor != null) cursor.close();
    }

    // 입력
    public boolean insert(StudentVo vo) {
        SQLiteDatabase database = helper.getWritableDatabase();
        String sql = "insert into tbl_student" +
                "   values(?, ?, ?, ?, ?, ?)";
        SQLiteStatement statement = database.compileStatement(sql);
        try {
            statement.bindString(1, vo.getSno());
            statement.bindString(2, vo.getSname());
            statement.bindLong(3, vo.getSyear());
            statement.bindString(4, vo.getGender());
            statement.bindString(5, vo.getMajor());
            statement.bindLong(6, vo.getScore());
            statement.executeInsert();
        } catch (SQLiteConstraintException sqe) {
            throw sqe;
        } finally {
            closeAll(database, statement, null);
        }
        return true;
    }

    // 수정
    public boolean update(StudentVo vo) {
        SQLiteDatabase database = helper.getWritableDatabase();
        String sql = "update tbl_student " +
                "       set sname = ?, syear = ?, gender = ?, major = ?, score = ?" +
                "       where sno = ?";
        SQLiteStatement statement = database.compileStatement(sql);
        statement.bindString(1, vo.getSname());
        statement.bindLong(2, vo.getSyear());
        statement.bindString(3, vo.getGender());
        statement.bindString(4, vo.getMajor());
        statement.bindLong(5, vo.getScore());
        statement.bindString(6, vo.getSno());
        statement.executeUpdateDelete();
        closeAll(database, statement, null);

        return true;
    }

    // 삭제
    public boolean delete(String sno) {
        SQLiteDatabase database = helper.getWritableDatabase();
        String sql = "delete from tbl_student where sno = '" + sno + "'";
        SQLiteStatement statement = database.compileStatement(sql);
        statement.executeUpdateDelete();
        closeAll(database, statement, null);
        return true;
    }

    // 조회
    public ArrayList<StudentVo> select() {
        SQLiteDatabase database = helper.getReadableDatabase();
        String sql = "select * from tbl_student";
        Cursor cursor = database.rawQuery(sql, null);
        ArrayList<StudentVo> list = new ArrayList<>();
        while (cursor.moveToNext()) {
            String sno = cursor.getString(0);
            String sname = cursor.getString(1);
            int syear = cursor.getInt(2);
            String gender = cursor.getString(3);
            String major = cursor.getString(4);
            int score = cursor.getInt(5);
            list.add(new StudentVo(sno, sname, syear, gender, major, score));
        }
        closeAll(database, null, cursor);
        Log.d("mytag", "list:" + list.toString());
        return list;
    }

    // 학번으로 정보 조회
    public StudentVo select1Student(String data) {
        SQLiteDatabase database = helper.getReadableDatabase();
        String sql = "select * from tbl_student where sno = '" + data + "'";
        Cursor cursor = database.rawQuery(sql, null);

        if (cursor.moveToNext()) {
            String sno = cursor.getString(0);
            String sname = cursor.getString(1);
            int syear = cursor.getInt(2);
            String gender = cursor.getString(3);
            String major = cursor.getString(4);
            int score = cursor.getInt(5);

            closeAll(database, null, cursor);
            return new StudentVo(sno, sname, syear, gender, major, score);
        }
        return null;
    }
}
