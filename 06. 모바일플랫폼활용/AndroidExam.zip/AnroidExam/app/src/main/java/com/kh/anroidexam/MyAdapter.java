package com.kh.anroidexam;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class MyAdapter extends BaseAdapter {

    Context context;
    int resource;
    ArrayList<StudentVo> list;
    TextView tvSno, tvSname, tvSyear, tvGender, tvMajor, tvScore;

    public MyAdapter(Context context, int resource, ArrayList<StudentVo> list) {
        this.context = context;
        this.resource = resource;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int index, View view, ViewGroup viewGroup) {

        if (view == null)
            view = View.inflate(context, resource, null);

        tvSno = view.findViewById(R.id.tvSno);
        tvSname = view.findViewById(R.id.tvSname);
        tvSyear = view.findViewById(R.id.tvSyear);
        tvGender = view.findViewById(R.id.tvGender);
        tvMajor = view.findViewById(R.id.tvMajor);
        tvScore = view.findViewById(R.id.tvScore);

        tvSno.setText(list.get(index).getSno());
        tvSname.setText(list.get(index).getSname());
        tvSyear.setText(String.valueOf(list.get(index).getSyear()));
        tvGender.setText(list.get(index).getGender());
        tvMajor.setText(list.get(index).getMajor());
        tvScore.setText(String.valueOf(list.get(index).getScore()));
        return view;
    }

    public void setList(ArrayList<StudentVo> list) {
        this.list = list;
    }
}
