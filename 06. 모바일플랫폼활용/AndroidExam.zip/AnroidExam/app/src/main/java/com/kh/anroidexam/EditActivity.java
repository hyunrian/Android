package com.kh.anroidexam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class EditActivity extends AppCompatActivity implements View.OnClickListener {

    EditText edSno, edSname, edSyear, edMajor, edScore;
    RadioButton rdM, rdF;
    Button btnOk, btnCancel;

    MyHelper helper;
    StudentDao dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        setTitle("학생 정보 수정");

        helper = new MyHelper(getApplicationContext(), "student.db", null, 1);
        dao = new StudentDao(helper);

        setUI();

        btnOk.setOnClickListener(this);
        btnCancel.setOnClickListener(this);

        setData();
    }

    private void setUI() {
        edSno = findViewById(R.id.edSno);
        edSname = findViewById(R.id.edSname);
        edSyear = findViewById(R.id.edSyear);
        edMajor = findViewById(R.id.edMajor);
        edScore = findViewById(R.id.edScore);
        rdF = findViewById(R.id.rdF);
        rdM = findViewById(R.id.rdM);
        btnOk = findViewById(R.id.btnOk);
        btnCancel = findViewById(R.id.btnCancel);
    }

    private void setData() {
        try {
            Intent intent = getIntent();
            String sno = intent.getStringExtra("sno");
            StudentVo vo = dao.select1Student(sno);
            edSno.setText(vo.getSno());
            edSname.setText(vo.getSname());
            edSyear.setText(String.valueOf(vo.getSyear()));
            edMajor.setText(vo.getMajor());
            edScore.setText(String.valueOf(vo.getScore()));
            if (vo.getGender().equals("M")) rdM.setChecked(true);
            else rdF.setChecked(true);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(),
                    "수정할 항목을 선택하세요", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    @Override
    public void onClick(View view) {
        if (view == btnOk) {
            String sno = edSno.getText().toString();
            String sname = edSname.getText().toString();
            int syear = Integer.valueOf(edSyear.getText().toString());
            String major = edMajor.getText().toString();
            int score = Integer.valueOf(edScore.getText().toString());
            String gender = "";
            if (rdF.isChecked()) gender = "F";
            else gender = "M";

            dao.update(new StudentVo(sno, sname, syear, gender, major, score));
            Toast.makeText(getApplicationContext(), "수정 완료", Toast.LENGTH_SHORT).show();
        }
        finish();
    }
}