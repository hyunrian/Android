package com.kh.anroidexam;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteConstraintException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    MyHelper helper;
    StudentDao dao;
    MyAdapter adapter;

    Button btnInsert, btnUpdate, btnSelect;
    ListView listView;
    ArrayList<StudentVo> list;
    String selectedSno;
    TextView[] tvs = new TextView[6];
    int[] ids = {
            R.id.tvSno, R.id.tvSname, R.id.tvSyear, R.id.tvGender, R.id.tvMajor, R.id.tvScore
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("학생 관리 프로그램");

        helper = new MyHelper(getApplicationContext(), "student.db", null, 1);
        dao = new StudentDao(helper);

        setUI();
        setListener();

        list = dao.select();
        adapter = new MyAdapter(getApplicationContext(), R.layout.view_cell, list);
        listView.setAdapter(adapter);
    }

    private void setListener() {
        btnInsert.setOnClickListener(this);
        btnUpdate.setOnClickListener(this);
        btnSelect.setOnClickListener(this);
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() { // 데이터 삭제
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                list = dao.select();
                String sno = list.get(i).getSno();
                boolean result = dao.delete(sno);
                if (result) showToast("삭제 완료");
                Log.d("mytag", list.toString());
                adapter.notifyDataSetChanged();
                return result;
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                list = dao.select();
                selectedSno = list.get(i).getSno();
                Log.d("mytag", selectedSno);
            }
        });
    }

    private void setUI() {
        btnInsert = findViewById(R.id.btnInsert);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnSelect = findViewById(R.id.btnSelect);
        listView = findViewById(R.id.listView);

//        for (int i = 0; i < tvs.length; i++) {
//            tvs[i] = findViewById(ids[i]);
//            tvs[i].setVisibility(View.VISIBLE);
//        }
    }

    @Override
    public void onClick(View view) {

        if (view == btnInsert) {
            View view_dialog = View.inflate(this, R.layout.view_dialog, null);
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.setView(view_dialog);
            dialog.setTitle("학생 정보 입력");

            EditText edSno = view_dialog.findViewById(R.id.edSno);
            EditText edSname = view_dialog.findViewById(R.id.edSname);
            EditText edSyear = view_dialog.findViewById(R.id.edSyear);
            RadioGroup rdGroup = view_dialog.findViewById(R.id.rdGroup);
            EditText edMajor = view_dialog.findViewById(R.id.edMajor);
            EditText edScore = view_dialog.findViewById(R.id.edScore);

            dialog.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    try {
                        String sno = edSno.getText().toString().trim();
                        String sname = edSname.getText().toString().trim();
                        int syear = Integer.valueOf(edSyear.getText().toString().trim());
                        String major = edMajor.getText().toString().trim();
                        String gender = "";
                        int id = rdGroup.getCheckedRadioButtonId();
                        if (id == R.id.rdF) gender = "F";
                        else if (id == R.id.rdM) gender = "M";
                        int score = Integer.valueOf(edScore.getText().toString().trim());

                        if (sno.length() > 8) {
                            showToast("학번은 8자리 숫자로 입력하세요");
                            return;
                        }
                        if (score > 100) {
                            showToast("점수는 100점 이하로 입력하세요");
                            return;
                        }

                        boolean result = dao.insert(new StudentVo(sno, sname, syear, gender, major, score));
//                        Log.d("mytag", new StudentVo(sno, sname, syear, gender, major, score).toString());
                        if (result) showToast("입력 완료");
                        adapter.notifyDataSetChanged();
                    } catch (SQLiteConstraintException sqe) {
                        showToast("중복된 학번입니다");
                    } catch (NumberFormatException ne) {
                        showToast("모든 항목을 정확히 입력하세요");
                    }
                }
            });
            dialog.setNegativeButton("취소", null);
            dialog.show();

        } else if (view == btnUpdate) { // 수정
            try {
                Intent intent = new Intent(getApplicationContext(), EditActivity.class);
                intent.putExtra("sno", selectedSno);
                startActivity(intent);
            } catch (Exception e) {
                showToast("수정할 항목을 선택하세요");
            }

        } else if (view == btnSelect) { // 조회
            for (int i = 0; i < tvs.length; i++) {
                tvs[i] = findViewById(ids[i]);
                tvs[i].setVisibility(View.VISIBLE);
            }
            listView.setVisibility(View.VISIBLE);
            list = dao.select();
            adapter.setList(list);
            adapter.notifyDataSetChanged();
        }

    }

    private void showToast(String str) {
        Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
    }
}